import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import BernoulliNB, GaussianNB, MultinomialNB
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn import metrics
import matplotlib.pyplot as plt
import joblib

print("--- Starting Data Preprocessing (Labs 9 & 10) ---")

data = pd.read_csv('crime_data.csv')

print(f"Initial Rows: {data.shape[0]}, Columns: {data.shape[1]}")
print("Null values per column:\n", data.isnull().sum())
initial_rows = data.shape[0]
data.drop_duplicates(inplace=True)
print(f"Dropped {initial_rows - data.shape[0]} duplicate rows.")

data['Offender_Age'] = data['Offender_Age'].astype(np.int64)
data['Victim_Age'] = data['Victim_Age'].astype(np.int64)
print("Data types after age conversion:\n", data.dtypes)

X = data.iloc[:, 0:-1]
y = data.iloc[:,-1]
print(f"X shape: {X.shape}, Y shape: {y.shape}")

cat_columns = X.select_dtypes(['object']).columns
category_map = {label: index for index, label in enumerate(y.unique())}

for col in cat_columns:
    X[col], _ = pd.factorize(X[col])

print("Features after factorization:\n", X.head().to_markdown(index=False, numalign="left", stralign="left"))

X_train, X_test, Y_train, Y_test = train_test_split(X, y, test_size=0.3, shuffle=False, random_state=42)
print(f"Train/Test split: X_train={X_train.shape}, X_test={X_test.shape}")

print("\n--- Starting Model Training and Evaluation (Lab 11) ---")

models = {
    'Bernoulli': BernoulliNB(),
    'Random Forest': RandomForestClassifier(random_state=42),
    'Gaussian': GaussianNB(),
    'Decision Tree': DecisionTreeClassifier(random_state=42),
    'Multinomial': MultinomialNB(),
    'KNeighbors': KNeighborsClassifier()
}

results = {
    'Classifier': [],
    'Accuracy': [],
    'Precision': [],
    'Recall': [],
    'F1 Score': []
}

best_f1_score = -1
best_model_name = ""
best_model = None

Y_test_encoded = y.map(category_map)[Y_test.index]

for name, model in models.items():
    model.fit(X_train, Y_train.map(category_map))
    Y_pred_encoded = model.predict(X_test)
    accuracy = metrics.accuracy_score(Y_test_encoded, Y_pred_encoded)
    precision = metrics.precision_score(Y_test_encoded, Y_pred_encoded, average='weighted', zero_division=0)
    recall = metrics.recall_score(Y_test_encoded, Y_pred_encoded, average='weighted', zero_division=0)
    f1 = metrics.f1_score(Y_test_encoded, Y_pred_encoded, average='weighted', zero_division=0)

    results['Classifier'].append(name)
    results['Accuracy'].append(accuracy)
    results['Precision'].append(precision)
    results['Recall'].append(recall)
    results['F1 Score'].append(f1)

    if f1 > best_f1_score:
        best_f1_score = f1
        best_model_name = name
        best_model = model

print("\n--- Model Evaluation Results (F1 Score determines Best Model) ---")
results_df = pd.DataFrame(results)
print(results_df.sort_values(by='F1 Score', ascending=False).to_markdown(index=False, numalign="left", stralign="left"))
print(f"\nBest Model for Deployment: {best_model_name} (F1 Score: {best_f1_score:.4f})")

plt.figure(figsize=(14, 8))
classifiers = results['Classifier']
metrics_data = {
    'Accuracy': results['Accuracy'],
    'Precision': results['Precision'],
    'Recall': results['Recall'],
    'F1 Score': results['F1 Score']
}
for metric, scores in metrics_data.items():
    plt.plot(classifiers, scores, marker='o', label=metric)
plt.title("Scores of Applied Classifiers", fontsize=16)
plt.xlabel("Classifiers", fontsize=12)
plt.ylabel("Score Value", fontsize=12)
plt.ylim(0, 1.05)
plt.legend()
plt.grid(True, linestyle='--', alpha=0.6)
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.savefig('classifier_scores_line_graph.png')
print("Saved line graph to classifier_scores_line_graph.png")

plt.figure(figsize=(10, 6))
plt.bar(results['Classifier'], results['F1 Score'], color=['#08737f', '#00898a', '#089f8f', '#39b48e', '#64c987', '#92dc7e'])
plt.title('F1 Scores of Applied Classifiers', fontsize=16)
plt.xlabel('Classifiers', fontsize=12)
plt.ylabel('F1 Scores', fontsize=12)
plt.ylim(0, 1.05)
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.savefig('classifier_f1_bar_graph.png')
print("Saved bar graph to classifier_f1_bar_graph.png")

joblib.dump(best_model, 'best_classifier_model.pkl')
joblib.dump(X.columns.tolist(), 'model_columns.pkl')

inverted_category_mapping = {index: label for label, index in category_map.items()}
joblib.dump(inverted_category_mapping, 'category_mapping.pkl')
print("\n--- Artifacts Saved for Deployment ---")
print(f"Best model ({best_model_name}) saved to best_classifier_model.pkl")
print("Deployment artifacts (columns & mapping) saved.")