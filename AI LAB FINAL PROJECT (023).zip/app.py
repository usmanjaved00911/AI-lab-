from flask import Flask, render_template, request
import joblib
import pandas as pd
import numpy as np

app = Flask(__name__)
try:
    model = joblib.load('best_classifier_model.pkl')
    model_columns = joblib.load('model_columns.pkl')
    category_mapping = joblib.load('category_mapping.pkl')
    BEST_MODEL_NAME = "Bernoulli Naive Bayes"
    print(f"Model ({BEST_MODEL_NAME}) and artifacts loaded successfully.")
except FileNotFoundError as e:
    print(f"ERROR: Missing file for deployment. Did you run 'crime_data_project.py'? ({e})")
    model = None
FEATURE_MAPPINGS = {
    'Disposition': {'CLOSED': 0, 'UNFOUNDED': 1, 'OPEN': 2, 'UNF-ADJ': 3},
    'OffenderStatus': {'ARRESTED': 0, 'NON-ARREST': 1, 'JUVENILE': 2, 'ARRESTED JUVENILE': 3, 'UNKNOWN': 4},
    'Offender_Race': {'BLACK': 0, 'NATIVE HAWAIIAN OR OTHER PACIFIC ISLANDER': 1, 'WHITE': 2, 'ASIAN': 3, 'AMERICAN INDIAN/ALASKA NATIVE': 4, 'UNKNOWN': 5},
    'Offender_Gender': {'MALE': 0, 'FEMALE': 1, 'UNKNOWN': 2, 'MULTIPLE': 3},
    'PersonType': {'VICTIM': 0}, 
    'Victim_Race': {'BLACK': 0, 'WHITE': 1, 'ASIAN': 2, 'AMERICAN INDIAN/ALASKA NATIVE': 3, 'UNKNOWN': 4, 'NATIVE HAWAIIAN OR OTHER PACIFIC ISLANDER': 5},
    'Victim_Gender': {'FEMALE': 0, 'MALE': 1, 'UNKNOWN': 2},
    'Victim_Fatal_Status': {'Non-fatal': 0, 'Fatal': 1},
    'Report Type': {'Supplemental Report': 0, 'Incident Report': 1, 'MISC': 2}
}

@app.route('/', methods=['GET', 'POST'])
def index():
    prediction_text = None
    if request.method == 'POST' and model is not None:
        try:
            form_data = request.form
            input_data_list = []

            for col in model_columns:
                value = form_data.get(col)
                
                if col in ['Offender_Age', 'Victim_Age']:
                    input_data_list.append(int(value))
                elif col in FEATURE_MAPPINGS:
                    mapped_value = FEATURE_MAPPINGS[col].get(value)
                    if mapped_value is None:
                         raise ValueError(f"Invalid input '{value}' for feature '{col}'.")
                    input_data_list.append(mapped_value)
                else:
                    raise ValueError(f"Deployment error: Missing handler for column: {col}")

            X_pred = pd.DataFrame([input_data_list], columns=model_columns)

            prediction_encoded = model.predict(X_pred)[0]
            
            prediction_category = category_mapping.get(prediction_encoded, "Unknown Category")
            
            prediction_text = f"Predicted Crime Category: {prediction_category}"

        except Exception as e:
            prediction_text = f"Prediction Error: {e}"
    
    return render_template('index.html', feature_mappings=FEATURE_MAPPINGS, prediction_text=prediction_text)

if __name__ == '__main__':
    app.run(debug=True)